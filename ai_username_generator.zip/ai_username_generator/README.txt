AI Username Generator Website

Files included:
- index.html
- style.css
- script.js

How to upload for free using Cloudflare Pages:
1. Go to dash.cloudflare.com and make a free account.
2. Search for Pages.
3. Choose Upload assets.
4. Upload these 3 files together.
5. Click Deploy.
6. Cloudflare gives you a free website link ending in pages.dev.

How to upload for free using GitHub Pages:
1. Make a free GitHub account.
2. Create a new repository.
3. Upload index.html, style.css and script.js.
4. Go to Settings > Pages.
5. Choose Deploy from branch, then main/root.
6. Save and wait for the website link.

Money ideas later:
- Add Google AdSense when the site gets traffic.
- Add affiliate links for gaming accessories or social media tools.
- Sell a premium downloadable username pack.
